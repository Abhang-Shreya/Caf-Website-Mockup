document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  document.getElementById("msg").textContent =
    "Thank you for contacting Brew Haven Café! ☕ We'll get back soon.";
  e.target.reset();
});